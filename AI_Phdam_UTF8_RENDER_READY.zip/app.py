"""AI Phdam: simple Vietnamese component assistant."""
import base64
import os
from pathlib import Path

import requests
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from PIL import Image, UnidentifiedImageError
from io import BytesIO

from utils.resistor_reader import read_4_band

BASE_DIR = Path(__file__).resolve().parent
MAX_BYTES = 8 * 1024 * 1024
ALLOWED_MIME = {"image/jpeg", "image/png", "image/webp", "image/gif"}

app = FastAPI(
    title="AI Phdam",
    description="Trợ lý phân tích linh kiện điện tử; cần OPENAI_API_KEY để bật nhận diện ảnh AI.",
    version="1.0.0",
)
origins = [x.strip() for x in os.getenv("ALLOWED_ORIGINS", "*").split(",") if x.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

@app.get("/")
def home():
    return FileResponse(BASE_DIR / "static" / "index.html")

@app.get("/api/health")
def health():
    key_ready = bool(os.getenv("OPENAI_API_KEY"))
    return {"ok": True, "service": "AI Phdam", "vision_model": os.getenv("OPENAI_MODEL", "gpt-4.1-mini"), "vision_ready": key_ready}

@app.get("/api/info")
def info():
    return {"app": "AI Phdam", "message": "Trợ lý nhận diện linh kiện điện tử", "vision_ready": bool(os.getenv("OPENAI_API_KEY"))}

@app.post("/api/analyze")
async def analyze(file: UploadFile = File(...)):
    mime = (file.content_type or "").lower()
    if mime not in ALLOWED_MIME:
        raise HTTPException(status_code=415, detail="Bồ hãy chọn ảnh JPG, PNG, WEBP hoặc GIF.")
    data = await file.read(MAX_BYTES + 1)
    if not data:
        raise HTTPException(status_code=400, detail="Tệp ảnh đang trống.")
    if len(data) > MAX_BYTES:
        raise HTTPException(status_code=413, detail="Ảnh quá lớn. Giới hạn là 8 MB.")
    try:
        # Verify the actual image, not just the client-supplied MIME type.
        with Image.open(BytesIO(data)) as im:
            if im.format not in {"JPEG", "PNG", "WEBP", "GIF"}:
                raise HTTPException(status_code=415, detail="Định dạng ảnh thực tế không được hỗ trợ.")
            width, height = im.size
            if width < 1 or height < 1 or width * height > 20_000_000:
                raise HTTPException(status_code=413, detail="Ảnh có kích thước điểm ảnh quá lớn. Hãy thu nhỏ ảnh rồi thử lại.")
            im.verify()
    except HTTPException:
        raise
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError, Image.DecompressionBombWarning):
        raise HTTPException(status_code=400, detail="Tệp tải lên không phải ảnh hợp lệ hoặc ảnh bị lỗi.")

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise HTTPException(status_code=503, detail="AI nhận diện ảnh chưa được bật. Cần thêm OPENAI_API_KEY trong Environment của Render. Các phần còn lại đã chạy, nhưng chưa thể phân tích ảnh bằng AI thật.")

    encoded = base64.b64encode(data).decode("ascii")
    data_url = f"data:{mime};base64,{encoded}"
    model = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
    prompt = (
        "Bạn là AI Phdam, trợ lý kỹ thuật điện tử bằng tiếng Việt. Hãy xem ảnh và trả lời có cấu trúc rõ ràng: "
        "(1) tên/loại linh kiện và mức độ chắc chắn; (2) dấu hiệu nhìn thấy như chữ in, mã linh kiện, số chân, vạch màu; "
        "(3) chức năng thường gặp; (4) cách kiểm tra bằng đồng hồ vạn năng an toàn; (5) lưu ý không cấp điện nếu chưa xác định. "
        "Không đoán chắc khi ảnh mờ hoặc không đủ dữ kiện; nói rõ cần ảnh cận cảnh nào. Không khẳng định giá trị điện áp/công suất chỉ từ ảnh nếu không đọc được thông số."
    )
    try:
        response = requests.post(
            "https://api.openai.com/v1/responses",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={"model": model, "input": [{"role": "user", "content": [
                {"type": "input_text", "text": prompt},
                {"type": "input_image", "image_url": data_url, "detail": "high"}
            ]}]},
            timeout=90,
        )
    except requests.RequestException as exc:
        raise HTTPException(status_code=502, detail="Không kết nối được dịch vụ AI. Bồ kiểm tra mạng hoặc cấu hình API key.") from exc
    if response.status_code >= 400:
        try:
            detail = response.json().get("error", {}).get("message", "Dịch vụ AI trả về lỗi.")
        except (ValueError, AttributeError):
            detail = "Dịch vụ AI trả về lỗi."
        # Do not echo credentials or raw request data in user-facing errors.
        raise HTTPException(status_code=502, detail=f"Lỗi dịch vụ AI (HTTP {response.status_code}): {str(detail)[:300]}")
    try:
        payload = response.json()
    except ValueError as exc:
        raise HTTPException(status_code=502, detail="Dịch vụ AI trả về dữ liệu không hợp lệ.") from exc
    if not isinstance(payload, dict):
        raise HTTPException(status_code=502, detail="Dịch vụ AI trả về cấu trúc dữ liệu không hợp lệ.")
    pieces = []
    for item in payload.get("output", []):
        if not isinstance(item, dict):
            continue
        for part in item.get("content", []):
            if isinstance(part, dict) and part.get("type") == "output_text" and isinstance(part.get("text"), str):
                pieces.append(part["text"])
    answer = "\n".join(pieces).strip()
    if not answer:
        raise HTTPException(status_code=502, detail="AI chưa trả về nội dung. Bồ thử ảnh rõ hơn nhé.")
    return {"ok": True, "mode": "ai", "model": model, "filename": file.filename, "analysis": answer}

@app.post("/api/resistor")
def resistor(colors: list[str]):
    try:
        return read_4_band(colors)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
