from pathlib import Path
import sys
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app

client = TestClient(app.app)

def test_home_and_health_routes():
    assert client.get('/').status_code == 200
    health = client.get('/api/health')
    assert health.status_code == 200
    assert health.json()['service'] == 'AI Phdam'
    assert 'vision_ready' in health.json()

def test_info_route():
    response = client.get('/api/info')
    assert response.status_code == 200
    assert response.json()['app'] == 'AI Phdam'

def test_resistor_calculation():
    response = client.post('/api/resistor', json=['nâu', 'đen', 'đỏ', 'vàng kim'])
    assert response.status_code == 200
    assert response.json()['formatted'] == '1 kΩ'
    assert response.json()['tolerance'] == '±5%'

def test_resistor_rejects_invalid_tolerance():
    response = client.post('/api/resistor', json=['nâu', 'đen', 'đỏ', 'không rõ'])
    assert response.status_code == 400

def test_resistor_requires_four_colors():
    response = client.post('/api/resistor', json=['nâu', 'đen'])
    assert response.status_code == 400

def test_analyze_rejects_non_image():
    response = client.post('/api/analyze', files={'file': ('fake.png', b'not an image', 'image/png')})
    assert response.status_code == 400

def test_analyze_rejects_unsupported_mime():
    response = client.post('/api/analyze', files={'file': ('file.txt', b'abc', 'text/plain')})
    assert response.status_code == 415

def _png_bytes():
    from io import BytesIO
    from PIL import Image
    buffer = BytesIO()
    Image.new('RGB', (16, 16), color='white').save(buffer, format='PNG')
    return buffer.getvalue()

def test_analyze_valid_image_without_api_key_returns_clear_setup_error(monkeypatch):
    monkeypatch.delenv('OPENAI_API_KEY', raising=False)
    response = client.post('/api/analyze', files={'file': ('part.png', _png_bytes(), 'image/png')})
    assert response.status_code == 503
    assert 'OPENAI_API_KEY' in response.json()['detail']

def test_analyze_rejects_mime_spoofed_image():
    response = client.post('/api/analyze', files={'file': ('fake.jpg', b'not really an image', 'image/jpeg')})
    assert response.status_code == 400

def test_analyze_handles_successful_ai_response(monkeypatch):
    class FakeResponse:
        status_code = 200
        def json(self):
            return {'output': [{'content': [{'type': 'output_text', 'text': 'Đây là một linh kiện thử nghiệm.'}]}]}
    monkeypatch.setenv('OPENAI_API_KEY', 'test-key-not-real')
    monkeypatch.setattr(app.requests, 'post', lambda *args, **kwargs: FakeResponse())
    response = client.post('/api/analyze', files={'file': ('part.png', _png_bytes(), 'image/png')})
    assert response.status_code == 200
    assert response.json()['analysis'] == 'Đây là một linh kiện thử nghiệm.'
