# AI Phdam — bản rà soát và nâng cấp

Ứng dụng web tiếng Việt cho trợ lý linh kiện điện tử. Giao diện phù hợp điện thoại; backend FastAPI; cấu hình triển khai Render.

## Có trong bản này
- Phân tích ảnh JPG/PNG/WEBP/GIF qua OpenAI Responses API khi có `OPENAI_API_KEY`.
- Chọn và phân tích tối đa 6 ảnh mỗi lượt, tuần tự để giảm tải.
- Tính điện trở 4 vạch màu.
- Lịch sử cục bộ trên trình duyệt (tối đa 100 mục).
- Xuất lịch sử JSON, xuất CSV, nhập JSON sao lưu.
- Hiển thị trạng thái máy chủ và trạng thái cấu hình AI.
- Kiểm tra định dạng MIME và định dạng ảnh thực tế, giới hạn 8 MB mỗi ảnh và 20 megapixel; phản hồi lỗi có hướng dẫn.
- API health/info, tài liệu API tự động tại `/docs`.

## Triển khai Render
1. Đưa nội dung bên trong ZIP vào thư mục gốc repo GitHub, không chỉ tải ZIP như một tệp.
2. Build Command: `pip install -r requirements.txt && python -m pip install "uvicorn[standard]>=0.30,<1.0"`
3. Start Command: `python -m uvicorn app:app --host 0.0.0.0 --port $PORT`
4. Trong Render → Environment, thêm `OPENAI_API_KEY` bằng API key của chính bạn. Không gửi key vào chat và không commit key lên GitHub.
5. Deploy lại, mở `/api/health`. Trường `vision_ready` phải là `true` để bật phân tích ảnh AI thật.

## Chạy và kiểm tra cục bộ
```bash
pip install -r requirements.txt
python -m pytest -q  # bộ kiểm thử hiện tại: 10 bài đạt
python -m uvicorn app:app --host 127.0.0.1 --port 8000
```

## API
- `GET /`
- `GET /api/health`
- `GET /api/info`
- `POST /api/analyze` multipart field `file`
- `POST /api/resistor` JSON array gồm 4 màu
- `GET /docs`

## Giới hạn và quyền riêng tư
- Lịch sử xuất/nhập được lưu trong trình duyệt hiện tại, không đồng bộ đám mây và có thể mất khi xóa dữ liệu trình duyệt.
- Không lưu ảnh lên server lâu dài; ảnh được gửi đến nhà cung cấp AI khi người dùng bấm phân tích.
- Kết quả thị giác AI có thể sai; cần đối chiếu mã linh kiện/datasheet và đo thực tế trước khi cấp điện.
- Chưa có tài khoản người dùng, đồng bộ giữa thiết bị, thanh toán hoặc kiểm thử tải production.
- API vision có thể phát sinh chi phí theo tài khoản OpenAI.
