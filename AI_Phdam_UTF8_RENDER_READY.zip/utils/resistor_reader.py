"""Simple calculator for a 4-band resistor using Vietnamese color names."""
COLORS = {
    "đen": 0, "den": 0, "nâu": 1, "nau": 1, "đỏ": 2, "do": 2,
    "cam": 3, "vàng": 4, "vang": 4, "lục": 5, "luc": 5,
    "xanh lá": 5, "xanh la": 5, "lam": 6, "xanh dương": 6, "xanh duong": 6, "tím": 7, "tim": 7,
    "xám": 8, "xam": 8, "trắng": 9, "trang": 9,
}
MULTIPLIERS = {
    "đen": 1, "den": 1, "nâu": 10, "nau": 10, "đỏ": 100, "do": 100,
    "cam": 1000, "vàng": 10000, "vang": 10000, "lục": 100000, "luc": 100000,
    "xanh lá": 100000, "xanh la": 100000, "lam": 1000000, "xanh dương": 1000000, "xanh duong": 1000000, "tím": 10000000, "tim": 10000000,
    "xám": 100000000, "xam": 100000000, "trắng": 1000000000, "trang": 1000000000,
    "vàng kim": 0.1, "vang kim": 0.1, "bạc": 0.01, "bac": 0.01,
}
TOLERANCES = {"nâu": "±1%", "nau": "±1%", "đỏ": "±2%", "do": "±2%", "xanh lá": "±0.5%", "xanh la": "±0.5%", "lam": "±0.25%", "xanh dương": "±0.25%", "xanh duong": "±0.25%", "tím": "±0.1%", "tim": "±0.1%", "xám": "±0.05%", "xam": "±0.05%", "vàng kim": "±5%", "vang kim": "±5%", "bạc": "±10%", "bac": "±10%"}

def read_4_band(colors):
    if not isinstance(colors, list) or len(colors) != 4:
        raise ValueError("Cần đúng 4 màu: 2 chữ số, hệ số nhân, sai số.")
    c = [str(x).strip().lower() for x in colors]
    if c[0] not in COLORS or c[1] not in COLORS:
        raise ValueError("Hai màu đầu phải là màu chữ số hợp lệ.")
    if c[2] not in MULTIPLIERS:
        raise ValueError("Màu thứ ba chưa được hỗ trợ làm hệ số nhân.")
    value = (COLORS[c[0]] * 10 + COLORS[c[1]]) * MULTIPLIERS[c[2]]
    if c[3] not in TOLERANCES:
        raise ValueError("Màu vạch sai số chưa hợp lệ hoặc chưa được hỗ trợ.")
    tol = TOLERANCES[c[3]]
    return {"ok": True, "mode": "calculator", "ohms": value, "formatted": _format_ohms(value), "tolerance": tol, "note": "Kết quả tính theo 4 vạch màu đã nhập; hãy đối chiếu datasheet hoặc đo thực tế."}

def _format_ohms(value):
    if value >= 1_000_000:
        return f"{value / 1_000_000:g} MΩ"
    if value >= 1000:
        return f"{value / 1000:g} kΩ"
    return f"{value:g} Ω"
