from pathlib import Path
import sys

from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app

client = TestClient(app.app)


def test_home_and_health_routes():
    assert client.get('/').status_code == 200
    health = client.get('/api/health')
    assert health.status_code == 200
    assert health.json()['service'] == 'AI Phdam'


def test_resistor_calculation():
    response = client.post('/api/resistor', json=['nâu', 'đen', 'đỏ', 'vàng kim'])
    assert response.status_code == 200
    assert response.json()['formatted'] == '1 kΩ'
    assert response.json()['tolerance'] == '±5%'


def test_resistor_rejects_invalid_tolerance():
    response = client.post('/api/resistor', json=['nâu', 'đen', 'đỏ', 'không rõ'])
    assert response.status_code == 400


def test_analyze_rejects_non_image():
    response = client.post('/api/analyze', files={'file': ('fake.png', b'not an image', 'image/png')})
    assert response.status_code == 400
