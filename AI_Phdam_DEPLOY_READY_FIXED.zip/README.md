# AI Phdam

Ứng dụng web tiếng Việt đơn giản để phân tích ảnh linh kiện điện tử và tính điện trở 4 vạch màu.

## Tính năng
- Giao diện điện thoại, tải ảnh JPG/PNG/WEBP/GIF tối đa 8 MB.
- API kiểm tra tình trạng tại `/api/health`.
- Tính điện trở 4 vạch màu tại `/api/resistor`.
- Phân tích ảnh bằng mô hình vision qua OpenAI Responses API khi cấu hình `OPENAI_API_KEY`.
- Nếu chưa có API key, ứng dụng báo rõ rằng nhận diện ảnh chưa được bật, không giả vờ đã nhận diện.

## Chạy local
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --reload
```
Mở `http://127.0.0.1:8000`.

## Deploy trên Render
1. Đưa toàn bộ tệp và thư mục bên trong ZIP lên thư mục gốc (root) của repo GitHub: `https://github.com/phdam/AI-Phdam` (đừng chỉ upload ZIP).
2. Trong Render chọn **New + → Web Service**, kết nối GitHub và chọn repo `AI-Phdam`.
3. Runtime: Python; Build command: `pip install -r requirements.txt`; Start command: `uvicorn app:app --host 0.0.0.0 --port $PORT`.
4. Sau khi tạo service, trong **Environment** thêm `OPENAI_API_KEY` với API key của chính bạn. Có thể đặt `OPENAI_MODEL` là `gpt-4.1-mini` (mặc định).
5. Chờ deploy xong, mở URL Render và `/api/health`.

Không đưa API key vào GitHub, mã nguồn, ảnh chụp màn hình hoặc gửi trong chat. Dùng secret/environment variable của Render. Dùng API vision có thể phát sinh phí theo tài khoản OpenAI.

## API
- `GET /api/health`
- `POST /api/analyze` multipart form field `file`
- `POST /api/resistor` JSON array, ví dụ `["nâu", "đen", "đỏ", "vàng kim"]`
- `GET /docs`

## Kiểm tra nhanh sau triển khai
- Trang chính: `/`
- Sức khỏe máy chủ: `/api/health`
- Thông tin ứng dụng: `/api/info`
- Tài liệu API: `/docs`
- Phân tích ảnh: `POST /api/analyze` với trường multipart `file`
- Tính điện trở: `POST /api/resistor` với JSON array gồm đúng 4 màu

## Smoke tests (tùy chọn)
Cài `pytest` trong môi trường phát triển rồi chạy `pytest -q`. Bộ test kiểm tra trang chủ, health route, phép tính điện trở và từ chối tệp không phải ảnh.
